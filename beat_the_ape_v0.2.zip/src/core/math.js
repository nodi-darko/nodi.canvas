Math.getRandomInt = function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}